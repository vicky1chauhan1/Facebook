package com.fb.test;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.fb.base.BasePage;
import com.fb.pages.ChangePassword;
import com.fb.pages.LoginPage;
import com.fb.pages.ProfilePage;
import com.fb.utils.Utils;

public class LoginTest {

	@BeforeTest
	public void browserLaunch() throws IOException {
		BasePage.initializeDriver();
		Utils.hitURL();
	}

	@Test
	public void fb_Login() throws IOException {
		new LoginPage().getLogin();
	}

	@Test
	public void fb_Status() {
		new ProfilePage().getStatus("Hello World");
	}

	@Test
	public void fb_pass_change() throws InterruptedException, IOException {
		new ChangePassword().getPasswordChange();
	}

}
