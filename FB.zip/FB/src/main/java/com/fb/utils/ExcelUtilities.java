package com.fb.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilities {

	public ArrayList<String> excelData() throws IOException {

		ArrayList<String> list = new ArrayList<String>();

		FileInputStream fis = new FileInputStream(".\\src\\main\\java\\excelFolder\\Test4.xlsx");

		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		int numberOfSheets = workbook.getNumberOfSheets();

		for (int i = 0; i < numberOfSheets; i++) {
			if (workbook.getSheetName(i).equalsIgnoreCase("Sheet1")) {
				XSSFSheet sheetAt = workbook.getSheetAt(i);
				Iterator<Row> rows = sheetAt.iterator();
				while (rows.hasNext()) {
					Row Row = rows.next();

					Iterator<Cell> cell = Row.cellIterator();
					while (cell.hasNext()) {
						Cell cellNext = cell.next();
						String stringCellValue = cellNext.getStringCellValue();

						list.add(stringCellValue);

					}
				}
			}

		}

		return list;

	}

	public void setExcelValue() throws IOException {

		FileInputStream fis = new FileInputStream(".\\src\\main\\java\\excelFolder\\Test4.xlsx");

		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		int numberOfSheets = workbook.getNumberOfSheets();

		for (int i = 0; i < numberOfSheets; i++) {
			if (workbook.getSheetName(i).equalsIgnoreCase("Sheet1")) {
				XSSFSheet sheetAt = workbook.getSheetAt(i);
				sheetAt.getRow(1).createCell(1).setCellValue(sheetAt.getRow(2).getCell(1).getStringCellValue());
				sheetAt.getRow(2).createCell(1).setCellValue(RandomStringUtils.randomAlphanumeric(10));

				FileOutputStream fos = new FileOutputStream(".\\src\\main\\java\\excelFolder\\Test4.xlsx");
				workbook.write(fos);
				break;
			}
		}
	}
}
