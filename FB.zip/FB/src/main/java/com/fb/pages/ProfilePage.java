package com.fb.pages;

import org.openqa.selenium.By;

import com.fb.utils.Utils;

public class ProfilePage {

	By home_icon = By.cssSelector("a[aria-label='Home']");
	By click_status_button = By.cssSelector(".hu5pjgll.op6gxeva");
	By cardSelect = By.xpath("//div[text()='Create a Text Story']");
	By textArea = By.cssSelector("textarea[class*='oajrlxb2 rq0escxv f1sip0of hidtqoto l']");
	By share_story = By.xpath("(//div[contains(@class,'tw6a2znq d')] //div[@class='kkf49tns cgat1ltu qypqp5cg buofh1pr'])[2]");
	
	
	
	public void getStatus(String text) {
		
		Utils.click(home_icon);
		Utils.click(click_status_button);
		Utils.click(cardSelect);
		Utils.sendKeys(textArea, text);
		Utils.click(share_story);
	}
}
