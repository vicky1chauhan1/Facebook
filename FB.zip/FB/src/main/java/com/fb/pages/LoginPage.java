package com.fb.pages;

import java.io.IOException;

import org.openqa.selenium.By;

import com.fb.utils.ExcelUtilities;
import com.fb.utils.Utils;

public class LoginPage {

	By email = By.cssSelector("input[class='inputtext _55r1 _6luy']");
	By pass = By.cssSelector(".inputtext._55r1._6luy._9npi");
	By login_button = By.cssSelector("._42ft._4jy0._6lth");

	public void getLogin() throws IOException {

		String id = new ExcelUtilities().excelData().get(1);
		String pwd = new ExcelUtilities().excelData().get(4);

		System.out.println(id + pwd);

		Utils.sendKeys(email, id);
		Utils.sendKeys(pass, pwd);
		Utils.click(login_button);
	}

}
