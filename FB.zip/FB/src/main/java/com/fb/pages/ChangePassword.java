package com.fb.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.fb.utils.ExcelUtilities;
import com.fb.utils.Utils;

public class ChangePassword {

	By profile_icon = By.xpath("//div[contains(@class,'du4w35lb l9j0dhe7 b')]/span");
	By drp_dwn_path1 = By.xpath("//div[@class='b20td4e0 muag1w35']/div");
	By drp_dwn_path2 = By.xpath("//div[contains(@class,'a8nywdso jba')]/div/div");
	By security_login = By.xpath("//a[contains(@href,'tab=security')]");
	By iframe = By.xpath("//iframe[@class='k4urcfbm jgljxmt5 a8c37x1j izx4hr6d humdl8nn bn081pho gcieejh5']");
	By changPWD = By.xpath("//span[text()='Change password']");
	By oldPass = By.cssSelector("input[id='password_old']");
	By newPass = By.cssSelector("input[id='password_new']");
	By confirmPass = By.cssSelector("input[id='password_confirm']");
	By save_changes_button = By.xpath("//label[@class='submit uiButton uiButtonConfirm']");
	By crossButton = By.cssSelector("a[title='Close']");

	public void getPasswordChange() throws InterruptedException, IOException {
		Utils.click(profile_icon);

		List<WebElement> path1 = Utils.path(drp_dwn_path1);

		for (WebElement value1 : path1) {
			if (value1.getText().equalsIgnoreCase("Settings & privacy")) {
				value1.click();
				break;
			}
		}

		List<WebElement> path2 = Utils.path(drp_dwn_path2);
		for (WebElement value2 : path2) {

			if (value2.getText().equalsIgnoreCase("Settings"))
				value2.click();
			break;
		}

		Utils.click(security_login);

		Thread.sleep(2000);

		Utils.frame_In(iframe);

		Utils.click(changPWD);

		Utils.sendKeys(oldPass, new ExcelUtilities().excelData().get(4));
		Utils.sendKeys(newPass, new ExcelUtilities().excelData().get(7));
		Utils.sendKeys(confirmPass, new ExcelUtilities().excelData().get(7));
		Utils.click(save_changes_button);
		Utils.click(crossButton);
		new ExcelUtilities().setExcelValue();

		Utils.frame_comeOut();

		Utils.click(new ProfilePage().home_icon);

	}

}
